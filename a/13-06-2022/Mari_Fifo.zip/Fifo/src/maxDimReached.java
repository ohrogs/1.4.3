public class maxDimReached extends Exception{
    maxDimReached(String msg){
        super(msg);
    }
}
