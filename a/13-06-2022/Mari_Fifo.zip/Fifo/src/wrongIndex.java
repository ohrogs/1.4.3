public class wrongIndex extends Exception{
    wrongIndex(String msg){
        super(msg);
    }
}
