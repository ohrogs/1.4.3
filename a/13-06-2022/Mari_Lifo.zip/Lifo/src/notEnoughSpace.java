public class notEnoughSpace extends Exception {
    notEnoughSpace(String msg) {
        super(msg);
    }
}
